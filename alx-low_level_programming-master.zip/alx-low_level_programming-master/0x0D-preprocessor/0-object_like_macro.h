#ifndef OBJECT_LIKE_MACRO
#define OBJECT_LIKE_MACRO

#define SIZE 1024

#endif
