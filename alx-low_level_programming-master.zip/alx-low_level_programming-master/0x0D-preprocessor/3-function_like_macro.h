#ifndef FUNCTION_LIKE_MACRO
#define FUNCTION_LIKE_MACRO

#define ABS(x) ((x) < (0) ? ((x) * (-1)) : (x))

#endif
