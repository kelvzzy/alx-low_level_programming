#include "main.h"

/**
 * add - Adds two integers and returns the result
 *@x: number being added
 *@y: number being added
 * Return: Always 0.
 */

int add(int x, int y)
{
	return (x + y);
}
