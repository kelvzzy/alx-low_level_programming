#ifndef SUM_LIKE_MACRO
#define SUM_LIKE_MACRO

#define SUM(x, y) ((x) + (y))

#endif
